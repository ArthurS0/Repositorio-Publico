const express = require('express');
const router = express.Router();
const db = require('../db');

router.post('/', (req, res) => {
    const { cliente_id, numero, tipo } = req.body;
    const query = `INSERT INTO telefone (cliente_id, numero, tipo) VALUES (?, ?, ?)`;
    db.query(query, [cliente_id, numero, tipo], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(201).json({ telefone_id: result.insertId });
    });
});

router.get('/', (req, res) => {
    const query = 'SELECT * FROM telefone';
    db.query(query, (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json(result);
    });
});

router.get('/:id', (req, res) => {
    const { id } = req.params;
    const query = 'SELECT * FROM telefone WHERE telefone_id = ?';
    db.query(query, [id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (result.length === 0) {
            return res.status(404).json({ error: 'Telefone não encontrado' });
        }
        res.status(200).json(result[0]);
    });
});

router.put('/:id', (req, res) => {
    const { id } = req.params;
    const { cliente_id, numero, tipo } = req.body;
    const query = `UPDATE telefone SET cliente_id = ?, numero = ?, tipo = ? WHERE telefone_id = ?`;
    db.query(query, [cliente_id, numero, tipo, id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json({ message: 'Telefone atualizado com sucesso!' });
    });
});

router.delete('/:id', (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM telefone WHERE telefone_id = ?';
    db.query(query, [id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json({ message: 'Telefone excluído com sucesso!' });
    });
});

module.exports = router;