const express = require('express');
const router = express.Router();
const db = require('../db');

router.post('/', (req, res) => {
    const { nome, cpf, email, endereco, data_nascimento, data_cadastro } = req.body;
    const query = `INSERT INTO clientes (nome, cpf, email, endereco, data_nascimento, data_cadastro) 
                   VALUES (?, ?, ?, ?, ?, ?)`;
    db.query(query, [nome, cpf, email, endereco, data_nascimento, data_cadastro], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(201).json({ cliente_id: result.insertId });
    });
});

router.get('/', (req, res) => {
    const query = 'SELECT * FROM clientes';
    db.query(query, (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json(result);
    });
});

router.get('/:id', (req, res) => {
    const { id } = req.params;
    const query = 'SELECT * FROM clientes WHERE cliente_id = ?';
    db.query(query, [id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (result.length === 0) {
            return res.status(404).json({ error: 'Cliente não encontrado' });
        }
        res.status(200).json(result[0]);
    });
});

router.put('/:id', (req, res) => {
    const { id } = req.params;
    const { nome, cpf, email, endereco, data_nascimento, data_cadastro } = req.body;
    const query = `UPDATE clientes SET nome = ?, cpf = ?, email = ?, endereco = ?, 
                   data_nascimento = ?, data_cadastro = ? WHERE cliente_id = ?`;
    db.query(query, [nome, cpf, email, endereco, data_nascimento, data_cadastro, id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json({ message: 'Cliente atualizado com sucesso!' });
    });
});

router.delete('/:id', (req, res) => {
    const { id } = req.params;
    const query = 'DELETE FROM clientes WHERE cliente_id = ?';
    db.query(query, [id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(200).json({ message: 'Cliente excluído com sucesso!' });
    });
});

module.exports = router;