const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'cinema'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Conectado ao banco de dados MySQL!');
});

app.post('/cadastro', (req, res) => {
    const { nome, email, senha } = req.body;

    bcrypt.hash(senha, 10, (err, hashedPassword) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Erro ao criptografar senha' });
        }

        const query = 'INSERT INTO clientes (nome, email, senha) VALUES (?, ?, ?)';
        db.query(query, [nome, email, hashedPassword], (err, result) => {
            if (err) {
                return res.status(500).json({ success: false, message: 'Erro ao cadastrar cliente' });
            }
            res.status(200).json({ success: true, message: 'Cliente cadastrado com sucesso' });
        });
    });
});

app.post('/login', (req, res) => {
    const { email, senha } = req.body;

    const query = 'SELECT * FROM clientes WHERE email = ?';
    db.query(query, [email], (err, result) => {
        if (err || result.length === 0) {
            return res.status(400).json({ success: false, message: 'Email ou senha inválidos' });
        }

        bcrypt.compare(senha, result[0].senha, (err, isMatch) => {
            if (err || !isMatch) {
                return res.status(400).json({ success: false, message: 'Email ou senha inválidos' });
            }
            res.status(200).json({ success: true, message: 'Login realizado com sucesso' });
        });
    });
});

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});