const params = new URLSearchParams(window.location.search);
const produto = params.get('produto');
const precoUnitario = parseFloat(params.get('preco'));

const productNameElement = document.getElementById('product-name');
const productPriceElement = document.getElementById('product-price');
const totalPriceElement = document.getElementById('total-price');
const quantityInput = document.getElementById('quantity');

productNameElement.textContent = `Produto: ${produto}`;
productPriceElement.textContent = `Preço Unitário: R$ ${precoUnitario.toFixed(2)}`;
updateTotalPrice(precoUnitario, 1);

quantityInput.addEventListener('input', () => {
    const quantity = parseInt(quantityInput.value) || 1;
    updateTotalPrice(precoUnitario, quantity);
});

function updateTotalPrice(preco, quantidade) {
    const total = preco * quantidade;
    totalPriceElement.textContent = `Total: R$ ${total.toFixed(2)}`;
}

const form = document.getElementById('purchase-form');
form.addEventListener('submit', (event) => {
    event.preventDefault();
    alert('Compra finalizada com sucesso!');
    window.location.href = "produtos.html";
});