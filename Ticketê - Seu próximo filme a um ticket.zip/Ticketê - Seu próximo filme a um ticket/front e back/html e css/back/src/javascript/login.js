const form = document.getElementById('login-form');

form.addEventListener('submit', function(event) {

    event.preventDefault();

    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;

    if (email === 'usuario@exemplo.com' && senha === 'senha123') {
        window.location.href = 'filmes.html';
    } else {
        alert('Email ou senha incorretos.');
    }
});