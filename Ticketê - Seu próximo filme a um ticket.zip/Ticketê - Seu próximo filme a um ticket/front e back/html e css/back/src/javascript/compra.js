function getURLParameter(name) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(name);
}

const produto = getURLParameter('produto');
const preco = getURLParameter('preco');

document.getElementById('produto-nome').textContent = `Produto: ${produto.charAt(0).toUpperCase() + produto.slice(1)}`;
document.getElementById('produto-preco').textContent = `Preço: R$ ${preco},00`;

const compraForm = document.getElementById('compra-form');
compraForm.addEventListener('submit', function(event) {
    event.preventDefault();

    const quantidade = document.getElementById('quantidade').value;
    const tamanho = document.getElementById('tamanho').value;
    const total = preco * quantidade;

    alert(`Você comprou ${quantidade} ${produto}(s) ${tamanho}(s). Total: R$ ${total},00`);
   
    window.location.href = 'filmes.html'; 
});