const db = require('../connect/db');

exports.createEstacionamento = (req, res) => {
    const { cliente_id, veiculo_placa, veiculo_marca, veiculo_modelo, data_entrada, data_saida } = req.body;
    const query = 'INSERT INTO estacionamento (cliente_id, veiculo_placa, veiculo_marca, veiculo_modelo, data_entrada, data_saida) VALUES (?, ?, ?, ?, ?, ?)';
    db.query(query, [cliente_id, veiculo_placa, veiculo_marca, veiculo_modelo, data_entrada, data_saida], (err, results) => {
        if (err) return res.status(500).send(err);
        res.status(201).json({ id: results.insertId });
    });
};

exports.getEstacionamentos = (req, res) => {
    db.query('SELECT * FROM estacionamento', (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
};

exports.getEstacionamentoById = (req, res) => {
    const query = 'SELECT * FROM estacionamento WHERE estacionamento_id = ?';
    db.query(query, [req.params.id], (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results[0]);
    });
};

exports.updateEstacionamento = (req, res) => {
    const { cliente_id, veiculo_placa, veiculo_marca, veiculo_modelo, data_entrada, data_saida } = req.body;
    const query = 'UPDATE estacionamento SET cliente_id = ?, veiculo_placa = ?, veiculo_marca = ?, veiculo_modelo = ?, data_entrada = ?, data_saida = ? WHERE estacionamento_id = ?';
    db.query(query, [cliente_id, veiculo_placa, veiculo_marca, veiculo_modelo, data_entrada, data_saida, req.params.id], (err) => {
        if (err) return res.status(500).send(err);
        res.sendStatus(204);
    });
};

exports.deleteEstacionamento = (req, res) => {
    const query = 'DELETE FROM estacionamento WHERE estacionamento_id = ?';
    db.query(query, [req.params.id], (err) => {
        if (err) return res.status(500).send(err);
        res.sendStatus(204);
    });
};