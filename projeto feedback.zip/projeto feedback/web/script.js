document.getElementById('feedbackForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const feedback = document.getElementById('feedback').value;

    const response = await fetch('http://localhost:3000/api/feedback', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            data: new Date().toISOString().split('T')[0],
            nome,
            email,
            feedback
        })
    });

    if (response.ok) {
        alert('Feedback enviado com sucesso!');
        loadFeedbacks();
    } else {
        alert('Erro ao enviar o feedback.');
    }
});

async function loadFeedbacks() {
    const response = await fetch('http://localhost:3000/api/feedbacks');
    const feedbacks = await response.json();

    const feedbackList = document.getElementById('feedbackList');
    feedbackList.innerHTML = '';
    feedbacks.forEach(feedback => {
        const li = document.createElement('li');
        li.textContent = `${feedback.nome}: ${feedback.feedback}`;
        feedbackList.appendChild(li);
    });
}

loadFeedbacks();
