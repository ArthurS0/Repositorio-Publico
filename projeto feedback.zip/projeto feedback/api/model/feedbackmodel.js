const db = require('./db');

const saveFeedback = (data, nome, email, feedback, callback) => {
  const query = 'INSERT INTO feedbacks (data, nome, email, feedback) VALUES (?, ?, ?, ?)';
  db.query(query, [data, nome, email, feedback], (err, result) => {
    if (err) {
      return callback(err);
    }
    callback(null, result);
  });
};

const getFeedbacks = (callback) => {
  const query = 'SELECT * FROM feedbacks ORDER BY data DESC';
  db.query(query, (err, results) => {
    if (err) {
      return callback(err);
    }
    callback(null, results);
  });
};

module.exports = { saveFeedback, getFeedbacks };
