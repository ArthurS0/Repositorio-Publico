const express = require('express');
const router = express.Router();
const feedbackModel = require('./feedbackModel');

router.get('/feedbacks', (req, res) => {
  feedbackModel.getFeedbacks((err, feedbacks) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao obter os feedbacks' });
    }
    res.json(feedbacks);
  });
});

router.post('/feedback', (req, res) => {
  const { data, nome, email, feedback } = req.body;
  feedbackModel.saveFeedback(data, nome, email, feedback, (err, result) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao salvar o feedback' });
    }
    res.status(201).json({ message: 'Feedback salvo com sucesso!' });
  });
});

module.exports = router;
