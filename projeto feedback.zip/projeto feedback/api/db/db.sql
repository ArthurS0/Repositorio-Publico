CREATE DATABASE feedbacks;
USE feedbacks;

CREATE TABLE feedbacks(
    feedback_id INTEGER PRIMARY KEY AUTO_INCREMENT,
    data DATE NOT NULL,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    feedback VARCHAR(255) NOT NULL
);

INSERT INTO feedbacks (data, nome, email, feedback)
VALUES
('2025-02-01', 'João Silva', 'joao.silva@email.com', 'Ótimo serviço, muito satisfeito!'),
('2025-02-10', 'Maria Oliveira', 'maria.oliveira@email.com', 'O atendimento poderia ser mais rápido.'),
('2025-02-15', 'Carlos Souza', 'carlos.souza@email.com', 'A experiência foi boa, mas o produto chegou danificado.'),
('2025-02-20', 'Ana Pereira', 'ana.pereira@email.com', 'Excelente! Superou minhas expectativas.'),
('2025-02-25', 'Luiz Costa', 'luiz.costa@email.com', 'O site é intuitivo, mas a entrega demorou mais do que o esperado.');

SELECT * FROM  feedbacks;