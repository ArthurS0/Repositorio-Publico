Passo 1 - npm start
Passo 2 - node server.js
Passo 3- Rodar a API no Insomnia